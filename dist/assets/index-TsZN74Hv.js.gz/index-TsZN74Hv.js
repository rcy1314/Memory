var Be=(e,o,r)=>new Promise((i,l)=>{var t=b=>{try{c(r.next(b))}catch(k){l(k)}},u=b=>{try{c(r.throw(b))}catch(k){l(k)}},c=b=>b.done?i(b.value):Promise.resolve(b.value).then(t,u);c((r=r.apply(e,o)).next())});import{_ as Xe}from"./TheIcon-Mohbq-MB.js";import{d as K,h as a,c as g,a as U,b as D,u as qe,dv as bt,A as ut,e as ee,aG as yt,p as at,dw as qt,dx as fe,dy as ae,dz as He,dA as ie,dB as le,dC as ne,dD as ke,dE as ve,dF as wt,dG as Qe,dH as oe,dI as Ye,dJ as et,r as N,j,dK as _e,dL as xe,f as kt,n as Ae,J as _t,dM as Re,dN as tt,dO as ot,dP as it,dl as Et,d9 as jt,aw as Lt,a8 as Kt,db as Gt,dc as Xt,g as Ee,dQ as Zt,t as pe,ab as Wt,aS as dt,k as xt,dd as Jt,de as Qt,z as he,aH as Q,ac as St,s as Yt,dR as eo,dS as to,w as oo,dT as io,q as ct,N as Se,dU as mt,bX as Ze,cA as We,K as ro,dV as lo,dW as ao,T as $e,Q as Y,a0 as v,R as S,F as no,U as so,X as Ve,_ as Pe,W as p,a1 as uo,a5 as co,o as mo,P as Ue,af as Fe,Z as pt,az as po}from"./index-ON-SflwH.js";import{N as z}from"./Input-Ck59uIzx.js";import{B as ho,V as fo,d as vo,e as rt,N as go}from"./Popover-DLxopjSP.js";import{_ as bo}from"./CommonPage-Dj5qqsUj.js";import{_ as yo}from"./_plugin-vue_export-helper-DlAUqK2U.js";import{a as $t,u as lt}from"./use-locale-gdUNdwpT.js";import{A as ht}from"./Add-CAjrcp6O.js";import{R as wo,N as ko}from"./InputNumber-BfqzlnEt.js";import{A as _o}from"./ArrowDown-CbBleTM8.js";import{N as xo,a as q}from"./FormItem-CFjxQbHB.js";import{N as Me}from"./Image-1TDPnt6y.js";import{N as Je}from"./Switch-D3pB72jH.js";import"./icon-oAdvG0qp.js";import"./Icon-BJkIY_JM.js";import"./format-length-B-p6aW7q.js";import"./AppPage-wwO3nDER.js";import"./Tooltip-Bg3keV3f.js";const So=K({name:"ArrowUp",render(){return a("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20"},a("g",{fill:"none"},a("path",{d:"M3.13 9.163a.5.5 0 1 0 .74.674L9.5 3.67V17.5a.5.5 0 0 0 1 0V3.672l5.63 6.165a.5.5 0 0 0 .738-.674l-6.315-6.916a.746.746 0 0 0-.632-.24a.746.746 0 0 0-.476.24L3.131 9.163z",fill:"currentColor"})))}}),$o=g("input-group",`
 display: inline-flex;
 width: 100%;
 flex-wrap: nowrap;
 vertical-align: bottom;
`,[U(">",[g("input",[U("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),U("&:not(:first-child)",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 margin-left: -1px!important;
 `)]),g("button",[U("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `,[D("state-border, border",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `)]),U("&:not(:first-child)",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `,[D("state-border, border",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `)])]),U("*",[U("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `,[U(">",[g("input",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),g("base-selection",[g("base-selection-label",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),g("base-selection-tags",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),D("box-shadow, border, state-border",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `)])])]),U("&:not(:first-child)",`
 margin-left: -1px!important;
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `,[U(">",[g("input",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),g("base-selection",[g("base-selection-label",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),g("base-selection-tags",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),D("box-shadow, border, state-border",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `)])])])])])]),Uo={},Co=K({name:"InputGroup",props:Uo,setup(e){const{mergedClsPrefixRef:o}=qe(e);return bt("-input-group",$o,o),{mergedClsPrefix:o}},render(){const{mergedClsPrefix:e}=this;return a("div",{class:`${e}-input-group`},this.$slots)}}),P="0!important",Ut="-1px!important";function be(e){return ee(`${e}-type`,[U("& +",[g("button",{},[ee(`${e}-type`,[D("border",{borderLeftWidth:P}),D("state-border",{left:Ut})])])])])}function ye(e){return ee(`${e}-type`,[U("& +",[g("button",[ee(`${e}-type`,[D("border",{borderTopWidth:P}),D("state-border",{top:Ut})])])])])}const Ro=g("button-group",`
 flex-wrap: nowrap;
 display: inline-flex;
 position: relative;
`,[ut("vertical",{flexDirection:"row"},[ut("rtl",[g("button",[U("&:first-child:not(:last-child)",`
 margin-right: ${P};
 border-top-right-radius: ${P};
 border-bottom-right-radius: ${P};
 `),U("&:last-child:not(:first-child)",`
 margin-left: ${P};
 border-top-left-radius: ${P};
 border-bottom-left-radius: ${P};
 `),U("&:not(:first-child):not(:last-child)",`
 margin-left: ${P};
 margin-right: ${P};
 border-radius: ${P};
 `),be("default"),ee("ghost",[be("primary"),be("info"),be("success"),be("warning"),be("error")])])])]),ee("vertical",{flexDirection:"column"},[g("button",[U("&:first-child:not(:last-child)",`
 margin-bottom: ${P};
 margin-left: ${P};
 margin-right: ${P};
 border-bottom-left-radius: ${P};
 border-bottom-right-radius: ${P};
 `),U("&:last-child:not(:first-child)",`
 margin-top: ${P};
 margin-left: ${P};
 margin-right: ${P};
 border-top-left-radius: ${P};
 border-top-right-radius: ${P};
 `),U("&:not(:first-child):not(:last-child)",`
 margin: ${P};
 border-radius: ${P};
 `),ye("default"),ee("ghost",[ye("primary"),ye("info"),ye("success"),ye("warning"),ye("error")])])])]),Vo={size:{type:String,default:void 0},vertical:Boolean},Po=K({name:"ButtonGroup",props:Vo,setup(e){const{mergedClsPrefixRef:o,mergedRtlRef:r}=qe(e);return bt("-button-group",Ro,o),at(qt,e),{rtlEnabled:yt("ButtonGroup",r,o),mergedClsPrefix:o}},render(){const{mergedClsPrefix:e}=this;return a("div",{class:[`${e}-button-group`,this.rtlEnabled&&`${e}-button-group--rtl`,this.vertical&&`${e}-button-group--vertical`],role:"group"},this.$slots)}});function Io(e,o){switch(e[0]){case"hex":return o?"#000000FF":"#000000";case"rgb":return o?"rgba(0, 0, 0, 1)":"rgb(0, 0, 0)";case"hsl":return o?"hsla(0, 0%, 0%, 1)":"hsl(0, 0%, 0%)";case"hsv":return o?"hsva(0, 0%, 0%, 1)":"hsv(0, 0%, 0%)"}return"#000000"}function Ie(e){return e===null?null:/^ *#/.test(e)?"hex":e.includes("rgb")?"rgb":e.includes("hsl")?"hsl":e.includes("hsv")?"hsv":null}function Ao(e){return e=Math.round(e),e>=360?359:e<0?0:e}function Do(e){return e=Math.round(e*100)/100,e>1?1:e<0?0:e}const zo={rgb:{hex(e){return ne(oe(e))},hsl(e){const[o,r,i,l]=oe(e);return ae([...et(o,r,i),l])},hsv(e){const[o,r,i,l]=oe(e);return ve([...Ye(o,r,i),l])}},hex:{rgb(e){return ie(oe(e))},hsl(e){const[o,r,i,l]=oe(e);return ae([...et(o,r,i),l])},hsv(e){const[o,r,i,l]=oe(e);return ve([...Ye(o,r,i),l])}},hsl:{hex(e){const[o,r,i,l]=ke(e);return ne([...Qe(o,r,i),l])},rgb(e){const[o,r,i,l]=ke(e);return ie([...Qe(o,r,i),l])},hsv(e){const[o,r,i,l]=ke(e);return ve([...wt(o,r,i),l])}},hsv:{hex(e){const[o,r,i,l]=fe(e);return ne([...le(o,r,i),l])},rgb(e){const[o,r,i,l]=fe(e);return ie([...le(o,r,i),l])},hsl(e){const[o,r,i,l]=fe(e);return ae([...He(o,r,i),l])}}};function Ct(e,o,r){return r=r||Ie(e),r?r===o?e:zo[r][o](e):null}const Ce="12px",Bo=12,ce="6px",Fo=K({name:"AlphaSlider",props:{clsPrefix:{type:String,required:!0},rgba:{type:Array,default:null},alpha:{type:Number,default:0},onUpdateAlpha:{type:Function,required:!0},onComplete:Function},setup(e){const o=N(null);function r(t){!o.value||!e.rgba||(_e("mousemove",document,i),_e("mouseup",document,l),i(t))}function i(t){const{value:u}=o;if(!u)return;const{width:c,left:b}=u.getBoundingClientRect(),k=(t.clientX-b)/(c-Bo);e.onUpdateAlpha(Do(k))}function l(){var t;xe("mousemove",document,i),xe("mouseup",document,l),(t=e.onComplete)===null||t===void 0||t.call(e)}return{railRef:o,railBackgroundImage:j(()=>{const{rgba:t}=e;return t?`linear-gradient(to right, rgba(${t[0]}, ${t[1]}, ${t[2]}, 0) 0%, rgba(${t[0]}, ${t[1]}, ${t[2]}, 1) 100%)`:""}),handleMouseDown:r}},render(){const{clsPrefix:e}=this;return a("div",{class:`${e}-color-picker-slider`,ref:"railRef",style:{height:Ce,borderRadius:ce},onMousedown:this.handleMouseDown},a("div",{style:{borderRadius:ce,position:"absolute",left:0,right:0,top:0,bottom:0,overflow:"hidden"}},a("div",{class:`${e}-color-picker-checkboard`}),a("div",{class:`${e}-color-picker-slider__image`,style:{backgroundImage:this.railBackgroundImage}})),this.rgba&&a("div",{style:{position:"absolute",left:ce,right:ce,top:0,bottom:0}},a("div",{class:`${e}-color-picker-handle`,style:{left:`calc(${this.alpha*100}% - ${ce})`,borderRadius:ce,width:Ce,height:Ce}},a("div",{class:`${e}-color-picker-handle__fill`,style:{backgroundColor:ie(this.rgba),borderRadius:ce,width:Ce,height:Ce}}))))}}),nt=kt("n-color-picker");function Mo(e){return/^\d{1,3}\.?\d*$/.test(e.trim())?Math.max(0,Math.min(Number.parseInt(e),255)):!1}function No(e){return/^\d{1,3}\.?\d*$/.test(e.trim())?Math.max(0,Math.min(Number.parseInt(e),360)):!1}function To(e){return/^\d{1,3}\.?\d*$/.test(e.trim())?Math.max(0,Math.min(Number.parseInt(e),100)):!1}function Oo(e){const o=e.trim();return/^#[0-9a-fA-F]+$/.test(o)?[4,5,7,9].includes(o.length):!1}function Ho(e){return/^\d{1,3}\.?\d*%$/.test(e.trim())?Math.max(0,Math.min(Number.parseInt(e)/100,100)):!1}const qo={paddingSmall:"0 4px"},ft=K({name:"ColorInputUnit",props:{label:{type:String,required:!0},value:{type:[Number,String],default:null},showAlpha:Boolean,onUpdateValue:{type:Function,required:!0}},setup(e){const o=N(""),{themeRef:r}=Ae(nt,null);_t(()=>{o.value=i()});function i(){const{value:u}=e;if(u===null)return"";const{label:c}=e;return c==="HEX"?u:c==="A"?`${Math.floor(u*100)}%`:String(Math.floor(u))}function l(u){o.value=u}function t(u){let c,b;switch(e.label){case"HEX":b=Oo(u),b&&e.onUpdateValue(u),o.value=i();break;case"H":c=No(u),c===!1?o.value=i():e.onUpdateValue(c);break;case"S":case"L":case"V":c=To(u),c===!1?o.value=i():e.onUpdateValue(c);break;case"A":c=Ho(u),c===!1?o.value=i():e.onUpdateValue(c);break;case"R":case"G":case"B":c=Mo(u),c===!1?o.value=i():e.onUpdateValue(c);break}}return{mergedTheme:r,inputValue:o,handleInputChange:t,handleInputUpdateValue:l}},render(){const{mergedTheme:e}=this;return a(z,{size:"small",placeholder:this.label,theme:e.peers.Input,themeOverrides:e.peerOverrides.Input,builtinThemeOverrides:qo,value:this.inputValue,onUpdateValue:this.handleInputUpdateValue,onChange:this.handleInputChange,style:this.label==="A"?"flex-grow: 1.25;":""})}}),Eo=K({name:"ColorInput",props:{clsPrefix:{type:String,required:!0},mode:{type:String,required:!0},modes:{type:Array,required:!0},showAlpha:{type:Boolean,required:!0},value:{type:String,default:null},valueArr:{type:Array,default:null},onUpdateValue:{type:Function,required:!0},onUpdateMode:{type:Function,required:!0}},setup(e){return{handleUnitUpdateValue(o,r){const{showAlpha:i}=e;if(e.mode==="hex"){e.onUpdateValue((i?ne:Re)(r));return}let l;switch(e.valueArr===null?l=[0,0,0,0]:l=Array.from(e.valueArr),e.mode){case"hsv":l[o]=r,e.onUpdateValue((i?ve:it)(l));break;case"rgb":l[o]=r,e.onUpdateValue((i?ie:ot)(l));break;case"hsl":l[o]=r,e.onUpdateValue((i?ae:tt)(l));break}}}},render(){const{clsPrefix:e,modes:o}=this;return a("div",{class:`${e}-color-picker-input`},a("div",{class:`${e}-color-picker-input__mode`,onClick:this.onUpdateMode,style:{cursor:o.length===1?"":"pointer"}},this.mode.toUpperCase()+(this.showAlpha?"A":"")),a(Co,null,{default:()=>{const{mode:r,valueArr:i,showAlpha:l}=this;if(r==="hex"){let t=null;try{t=i===null?null:(l?ne:Re)(i)}catch(u){}return a(ft,{label:"HEX",showAlpha:l,value:t,onUpdateValue:u=>{this.handleUnitUpdateValue(0,u)}})}return(r+(l?"a":"")).split("").map((t,u)=>a(ft,{label:t.toUpperCase(),value:i===null?null:i[u],onUpdateValue:c=>{this.handleUnitUpdateValue(u,c)}}))}}))}});function jo(e,o){if(o==="hsv"){const[r,i,l,t]=fe(e);return ie([...le(r,i,l),t])}return e}function Lo(e){const o=document.createElement("canvas").getContext("2d");return o?(o.fillStyle=e,o.fillStyle):"#000000"}const Ko=K({name:"ColorPickerSwatches",props:{clsPrefix:{type:String,required:!0},mode:{type:String,required:!0},swatches:{type:Array,required:!0},onUpdateColor:{type:Function,required:!0}},setup(e){const o=j(()=>e.swatches.map(t=>{const u=Ie(t);return{value:t,mode:u,legalValue:jo(t,u)}}));function r(t){const{mode:u}=e;let{value:c,mode:b}=t;return b||(b="hex",/^[a-zA-Z]+$/.test(c)?c=Lo(c):(Et("color-picker",`color ${c} in swatches is invalid.`),c="#000000")),b===u?c:Ct(c,u,b)}function i(t){e.onUpdateColor(r(t))}function l(t,u){t.key==="Enter"&&i(u)}return{parsedSwatchesRef:o,handleSwatchSelect:i,handleSwatchKeyDown:l}},render(){const{clsPrefix:e}=this;return a("div",{class:`${e}-color-picker-swatches`},this.parsedSwatchesRef.map(o=>a("div",{class:`${e}-color-picker-swatch`,tabindex:0,onClick:()=>{this.handleSwatchSelect(o)},onKeydown:r=>{this.handleSwatchKeyDown(r,o)}},a("div",{class:`${e}-color-picker-swatch__fill`,style:{background:o.legalValue}}))))}}),Go=K({name:"ColorPickerTrigger",slots:Object,props:{clsPrefix:{type:String,required:!0},value:{type:String,default:null},hsla:{type:Array,default:null},disabled:Boolean,onClick:Function},setup(e){const{colorPickerSlots:o,renderLabelRef:r}=Ae(nt,null);return()=>{const{hsla:i,value:l,clsPrefix:t,onClick:u,disabled:c}=e,b=o.label||r.value;return a("div",{class:[`${t}-color-picker-trigger`,c&&`${t}-color-picker-trigger--disabled`],onClick:c?void 0:u},a("div",{class:`${t}-color-picker-trigger__fill`},a("div",{class:`${t}-color-picker-checkboard`}),a("div",{style:{position:"absolute",left:0,right:0,top:0,bottom:0,backgroundColor:i?ae(i):""}}),l&&i?a("div",{class:`${t}-color-picker-trigger__value`,style:{color:i[2]>50||i[3]<.5?"black":"white"}},b?b(l):l):null))}}}),Xo=K({name:"ColorPreview",props:{clsPrefix:{type:String,required:!0},mode:{type:String,required:!0},color:{type:String,default:null,validator:e=>{const o=Ie(e);return!!(!e||o&&o!=="hsv")}},onUpdateColor:{type:Function,required:!0}},setup(e){function o(r){var i;const l=r.target.value;(i=e.onUpdateColor)===null||i===void 0||i.call(e,Ct(l.toUpperCase(),e.mode,"hex")),r.stopPropagation()}return{handleChange:o}},render(){const{clsPrefix:e}=this;return a("div",{class:`${e}-color-picker-preview__preview`},a("span",{class:`${e}-color-picker-preview__fill`,style:{background:this.color||"#000000"}}),a("input",{class:`${e}-color-picker-preview__input`,type:"color",value:this.color,onChange:this.handleChange}))}}),we="12px",Zo=12,me="6px",Wo=6,Jo="linear-gradient(90deg,red,#ff0 16.66%,#0f0 33.33%,#0ff 50%,#00f 66.66%,#f0f 83.33%,red)",Qo=K({name:"HueSlider",props:{clsPrefix:{type:String,required:!0},hue:{type:Number,required:!0},onUpdateHue:{type:Function,required:!0},onComplete:Function},setup(e){const o=N(null);function r(t){o.value&&(_e("mousemove",document,i),_e("mouseup",document,l),i(t))}function i(t){const{value:u}=o;if(!u)return;const{width:c,left:b}=u.getBoundingClientRect(),k=Ao((t.clientX-b-Wo)/(c-Zo)*360);e.onUpdateHue(k)}function l(){var t;xe("mousemove",document,i),xe("mouseup",document,l),(t=e.onComplete)===null||t===void 0||t.call(e)}return{railRef:o,handleMouseDown:r}},render(){const{clsPrefix:e}=this;return a("div",{class:`${e}-color-picker-slider`,style:{height:we,borderRadius:me}},a("div",{ref:"railRef",style:{boxShadow:"inset 0 0 2px 0 rgba(0, 0, 0, .24)",boxSizing:"border-box",backgroundImage:Jo,height:we,borderRadius:me,position:"relative"},onMousedown:this.handleMouseDown},a("div",{style:{position:"absolute",left:me,right:me,top:0,bottom:0}},a("div",{class:`${e}-color-picker-handle`,style:{left:`calc((${this.hue}%) / 359 * 100 - ${me})`,borderRadius:me,width:we,height:we}},a("div",{class:`${e}-color-picker-handle__fill`,style:{backgroundColor:`hsl(${this.hue}, 100%, 50%)`,borderRadius:me,width:we,height:we}})))))}}),Ne="12px",Te="6px",Yo=K({name:"Pallete",props:{clsPrefix:{type:String,required:!0},rgba:{type:Array,default:null},displayedHue:{type:Number,required:!0},displayedSv:{type:Array,required:!0},onUpdateSV:{type:Function,required:!0},onComplete:Function},setup(e){const o=N(null);function r(t){o.value&&(_e("mousemove",document,i),_e("mouseup",document,l),i(t))}function i(t){const{value:u}=o;if(!u)return;const{width:c,height:b,left:k,bottom:B}=u.getBoundingClientRect(),$=(B-t.clientY)/b,h=(t.clientX-k)/c,m=100*(h>1?1:h<0?0:h),R=100*($>1?1:$<0?0:$);e.onUpdateSV(m,R)}function l(){var t;xe("mousemove",document,i),xe("mouseup",document,l),(t=e.onComplete)===null||t===void 0||t.call(e)}return{palleteRef:o,handleColor:j(()=>{const{rgba:t}=e;return t?`rgb(${t[0]}, ${t[1]}, ${t[2]})`:""}),handleMouseDown:r}},render(){const{clsPrefix:e}=this;return a("div",{class:`${e}-color-picker-pallete`,onMousedown:this.handleMouseDown,ref:"palleteRef"},a("div",{class:`${e}-color-picker-pallete__layer`,style:{backgroundImage:`linear-gradient(90deg, white, hsl(${this.displayedHue}, 100%, 50%))`}}),a("div",{class:`${e}-color-picker-pallete__layer ${e}-color-picker-pallete__layer--shadowed`,style:{backgroundImage:"linear-gradient(180deg, rgba(0, 0, 0, 0%), rgba(0, 0, 0, 100%))"}}),this.rgba&&a("div",{class:`${e}-color-picker-handle`,style:{width:Ne,height:Ne,borderRadius:Te,left:`calc(${this.displayedSv[0]}% - ${Te})`,bottom:`calc(${this.displayedSv[1]}% - ${Te})`}},a("div",{class:`${e}-color-picker-handle__fill`,style:{backgroundColor:this.handleColor,borderRadius:Te,width:Ne,height:Ne}})))}}),ei=U([g("color-picker",`
 display: inline-block;
 box-sizing: border-box;
 height: var(--n-height);
 font-size: var(--n-font-size);
 width: 100%;
 position: relative;
 `),g("color-picker-panel",`
 margin: 4px 0;
 width: 240px;
 font-size: var(--n-panel-font-size);
 color: var(--n-text-color);
 background-color: var(--n-color);
 transition:
 box-shadow .3s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 box-shadow: var(--n-box-shadow);
 `,[jt(),g("input",`
 text-align: center;
 `)]),g("color-picker-checkboard",`
 background: white; 
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `,[U("&::after",`
 background-image: linear-gradient(45deg, #DDD 25%, #0000 25%), linear-gradient(-45deg, #DDD 25%, #0000 25%), linear-gradient(45deg, #0000 75%, #DDD 75%), linear-gradient(-45deg, #0000 75%, #DDD 75%);
 background-size: 12px 12px;
 background-position: 0 0, 0 6px, 6px -6px, -6px 0px;
 background-repeat: repeat;
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),g("color-picker-slider",`
 margin-bottom: 8px;
 position: relative;
 box-sizing: border-box;
 `,[D("image",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `),U("&::after",`
 content: "";
 position: absolute;
 border-radius: inherit;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 box-shadow: inset 0 0 2px 0 rgba(0, 0, 0, .24);
 pointer-events: none;
 `)]),g("color-picker-handle",`
 z-index: 1;
 box-shadow: 0 0 2px 0 rgba(0, 0, 0, .45);
 position: absolute;
 background-color: white;
 overflow: hidden;
 `,[D("fill",`
 box-sizing: border-box;
 border: 2px solid white;
 `)]),g("color-picker-pallete",`
 height: 180px;
 position: relative;
 margin-bottom: 8px;
 cursor: crosshair;
 `,[D("layer",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `,[ee("shadowed",`
 box-shadow: inset 0 0 2px 0 rgba(0, 0, 0, .24);
 `)])]),g("color-picker-preview",`
 display: flex;
 `,[D("sliders",`
 flex: 1 0 auto;
 `),D("preview",`
 position: relative;
 height: 30px;
 width: 30px;
 margin: 0 0 8px 6px;
 border-radius: 50%;
 box-shadow: rgba(0, 0, 0, .15) 0px 0px 0px 1px inset;
 overflow: hidden;
 `),D("fill",`
 display: block;
 width: 30px;
 height: 30px;
 `),D("input",`
 position: absolute;
 top: 0;
 left: 0;
 width: 30px;
 height: 30px;
 opacity: 0;
 z-index: 1;
 `)]),g("color-picker-input",`
 display: flex;
 align-items: center;
 `,[g("input",`
 flex-grow: 1;
 flex-basis: 0;
 `),D("mode",`
 width: 72px;
 text-align: center;
 `)]),g("color-picker-control",`
 padding: 12px;
 `),g("color-picker-action",`
 display: flex;
 margin-top: -4px;
 border-top: 1px solid var(--n-divider-color);
 padding: 8px 12px;
 justify-content: flex-end;
 `,[g("button","margin-left: 8px;")]),g("color-picker-trigger",`
 border: var(--n-border);
 height: 100%;
 box-sizing: border-box;
 border-radius: var(--n-border-radius);
 transition: border-color .3s var(--n-bezier);
 cursor: pointer;
 `,[D("value",`
 white-space: nowrap;
 position: relative;
 `),D("fill",`
 border-radius: var(--n-border-radius);
 position: absolute;
 display: flex;
 align-items: center;
 justify-content: center;
 left: 4px;
 right: 4px;
 top: 4px;
 bottom: 4px;
 `),ee("disabled","cursor: not-allowed"),g("color-picker-checkboard",`
 border-radius: var(--n-border-radius);
 `,[U("&::after",`
 --n-block-size: calc((var(--n-height) - 8px) / 3);
 background-size: calc(var(--n-block-size) * 2) calc(var(--n-block-size) * 2);
 background-position: 0 0, 0 var(--n-block-size), var(--n-block-size) calc(-1 * var(--n-block-size)), calc(-1 * var(--n-block-size)) 0px; 
 `)])]),g("color-picker-swatches",`
 display: grid;
 grid-gap: 8px;
 flex-wrap: wrap;
 position: relative;
 grid-template-columns: repeat(auto-fill, 18px);
 margin-top: 10px;
 `,[g("color-picker-swatch",`
 width: 18px;
 height: 18px;
 background-image: linear-gradient(45deg, #DDD 25%, #0000 25%), linear-gradient(-45deg, #DDD 25%, #0000 25%), linear-gradient(45deg, #0000 75%, #DDD 75%), linear-gradient(-45deg, #0000 75%, #DDD 75%);
 background-size: 8px 8px;
 background-position: 0px 0, 0px 4px, 4px -4px, -4px 0px;
 background-repeat: repeat;
 `,[D("fill",`
 position: relative;
 width: 100%;
 height: 100%;
 border-radius: 3px;
 box-shadow: rgba(0, 0, 0, .15) 0px 0px 0px 1px inset;
 cursor: pointer;
 `),U("&:focus",`
 outline: none;
 `,[D("fill",[U("&::after",`
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 left: 0;
 background: inherit;
 filter: blur(2px);
 content: "";
 `)])])])])]),ti=Object.assign(Object.assign({},Ee.props),{value:String,show:{type:Boolean,default:void 0},defaultShow:Boolean,defaultValue:String,modes:{type:Array,default:()=>["rgb","hex","hsl"]},placement:{type:String,default:"bottom-start"},to:rt.propTo,showAlpha:{type:Boolean,default:!0},showPreview:Boolean,swatches:Array,disabled:{type:Boolean,default:void 0},actions:{type:Array,default:null},internalActions:Array,size:String,renderLabel:Function,onComplete:Function,onConfirm:Function,onClear:Function,"onUpdate:show":[Function,Array],onUpdateShow:[Function,Array],"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array]}),oi=K({name:"ColorPicker",props:ti,slots:Object,setup(e,{slots:o}){const r=N(null);let i=null;const l=Xt(e),{mergedSizeRef:t,mergedDisabledRef:u}=l,{localeRef:c}=$t("global"),{mergedClsPrefixRef:b,namespaceRef:k,inlineThemeDisabled:B}=qe(e),$=Ee("ColorPicker","-color-picker",ei,Zt,e,b);at(nt,{themeRef:$,renderLabelRef:pe(e,"renderLabel"),colorPickerSlots:o});const h=N(e.defaultShow),m=lt(pe(e,"show"),h);function R(n){const{onUpdateShow:_,"onUpdate:show":I}=e;_&&he(_,n),I&&he(I,n),h.value=n}const{defaultValue:Z}=e,s=N(Z===void 0?Io(e.modes,e.showAlpha):Z),w=lt(pe(e,"value"),s),O=N([w.value]),E=N(0),C=j(()=>Ie(w.value)),{modes:se}=e,W=N(Ie(w.value)||se[0]||"rgb");function De(){const{modes:n}=e,{value:_}=W,I=n.findIndex(A=>A===_);~I?W.value=n[(I+1)%n.length]:W.value="rgb"}let F,d,f,x,y,H,J,G;const re=j(()=>{const{value:n}=w;if(!n)return null;switch(C.value){case"hsv":return fe(n);case"hsl":return[F,d,f,G]=ke(n),[...wt(F,d,f),G];case"rgb":case"hex":return[y,H,J,G]=oe(n),[...Ye(y,H,J),G]}}),ue=j(()=>{const{value:n}=w;if(!n)return null;switch(C.value){case"rgb":case"hex":return oe(n);case"hsv":return[F,d,x,G]=fe(n),[...le(F,d,x),G];case"hsl":return[F,d,f,G]=ke(n),[...Qe(F,d,f),G]}}),je=j(()=>{const{value:n}=w;if(!n)return null;switch(C.value){case"hsl":return ke(n);case"hsv":return[F,d,x,G]=fe(n),[...He(F,d,x),G];case"rgb":case"hex":return[y,H,J,G]=oe(n),[...et(y,H,J),G]}}),Rt=j(()=>{switch(W.value){case"rgb":case"hex":return ue.value;case"hsv":return re.value;case"hsl":return je.value}}),ze=N(0),Le=N(1),Ke=N([0,0]);function Vt(n,_){const{value:I}=re,A=ze.value,M=I?I[3]:1;Ke.value=[n,_];const{showAlpha:V}=e;switch(W.value){case"hsv":T((V?ve:it)([A,n,_,M]),"cursor");break;case"hsl":T((V?ae:tt)([...He(A,n,_),M]),"cursor");break;case"rgb":T((V?ie:ot)([...le(A,n,_),M]),"cursor");break;case"hex":T((V?ne:Re)([...le(A,n,_),M]),"cursor");break}}function Pt(n){ze.value=n;const{value:_}=re;if(!_)return;const[,I,A,M]=_,{showAlpha:V}=e;switch(W.value){case"hsv":T((V?ve:it)([n,I,A,M]),"cursor");break;case"rgb":T((V?ie:ot)([...le(n,I,A),M]),"cursor");break;case"hex":T((V?ne:Re)([...le(n,I,A),M]),"cursor");break;case"hsl":T((V?ae:tt)([...He(n,I,A),M]),"cursor");break}}function It(n){switch(W.value){case"hsv":[F,d,x]=re.value,T(ve([F,d,x,n]),"cursor");break;case"rgb":[y,H,J]=ue.value,T(ie([y,H,J,n]),"cursor");break;case"hex":[y,H,J]=ue.value,T(ne([y,H,J,n]),"cursor");break;case"hsl":[F,d,f]=je.value,T(ae([F,d,f,n]),"cursor");break}Le.value=n}function T(n,_){_==="cursor"?i=n:i=null;const{nTriggerFormChange:I,nTriggerFormInput:A}=l,{onUpdateValue:M,"onUpdate:value":V}=e;M&&he(M,n),V&&he(V,n),I(),A(),s.value=n}function At(n){T(n,"input"),St(ge)}function ge(n=!0){const{value:_}=w;if(_){const{nTriggerFormChange:I,nTriggerFormInput:A}=l,{onComplete:M}=e;M&&M(_);const{value:V}=O,{value:X}=E;n&&(V.splice(X+1,V.length,_),E.value=X+1),I(),A()}}function Dt(){const{value:n}=E;n-1<0||(T(O.value[n-1],"input"),ge(!1),E.value=n-1)}function zt(){const{value:n}=E;n<0||n+1>=O.value.length||(T(O.value[n+1],"input"),ge(!1),E.value=n+1)}function Bt(){T(null,"input");const{onClear:n}=e;n&&n(),R(!1)}function Ft(){const{value:n}=w,{onConfirm:_}=e;_&&_(n),R(!1)}const Mt=j(()=>E.value>=1),Nt=j(()=>{const{value:n}=O;return n.length>1&&E.value<n.length-1});Wt(m,n=>{n||(O.value=[w.value],E.value=0)}),_t(()=>{if(!(i&&i===w.value)){const{value:n}=re;n&&(ze.value=n[0],Le.value=n[3],Ke.value=[n[1],n[2]])}i=null});const Ge=j(()=>{const{value:n}=t,{common:{cubicBezierEaseInOut:_},self:{textColor:I,color:A,panelFontSize:M,boxShadow:V,border:X,borderRadius:L,dividerColor:de,[dt("height",n)]:Ot,[dt("fontSize",n)]:Ht}}=$.value;return{"--n-bezier":_,"--n-text-color":I,"--n-color":A,"--n-panel-font-size":M,"--n-font-size":Ht,"--n-box-shadow":V,"--n-border":X,"--n-border-radius":L,"--n-height":Ot,"--n-divider-color":de}}),te=B?xt("color-picker",j(()=>t.value[0]),Ge,e):void 0;function Tt(){var n;const{value:_}=ue,{value:I}=ze,{internalActions:A,modes:M,actions:V}=e,{value:X}=$,{value:L}=b;return a("div",{class:[`${L}-color-picker-panel`,te==null?void 0:te.themeClass.value],onDragstart:de=>{de.preventDefault()},style:B?void 0:Ge.value},a("div",{class:`${L}-color-picker-control`},a(Yo,{clsPrefix:L,rgba:_,displayedHue:I,displayedSv:Ke.value,onUpdateSV:Vt,onComplete:ge}),a("div",{class:`${L}-color-picker-preview`},a("div",{class:`${L}-color-picker-preview__sliders`},a(Qo,{clsPrefix:L,hue:I,onUpdateHue:Pt,onComplete:ge}),e.showAlpha?a(Fo,{clsPrefix:L,rgba:_,alpha:Le.value,onUpdateAlpha:It,onComplete:ge}):null),e.showPreview?a(Xo,{clsPrefix:L,mode:W.value,color:ue.value&&Re(ue.value),onUpdateColor:de=>{T(de,"input")}}):null),a(Eo,{clsPrefix:L,showAlpha:e.showAlpha,mode:W.value,modes:M,onUpdateMode:De,value:w.value,valueArr:Rt.value,onUpdateValue:At}),((n=e.swatches)===null||n===void 0?void 0:n.length)&&a(Ko,{clsPrefix:L,mode:W.value,swatches:e.swatches,onUpdateColor:de=>{T(de,"input")}})),V!=null&&V.length?a("div",{class:`${L}-color-picker-action`},V.includes("confirm")&&a(Q,{size:"small",onClick:Ft,theme:X.peers.Button,themeOverrides:X.peerOverrides.Button},{default:()=>c.value.confirm}),V.includes("clear")&&a(Q,{size:"small",onClick:Bt,disabled:!w.value,theme:X.peers.Button,themeOverrides:X.peerOverrides.Button},{default:()=>c.value.clear})):null,o.action?a("div",{class:`${L}-color-picker-action`},{default:o.action}):A?a("div",{class:`${L}-color-picker-action`},A.includes("undo")&&a(Q,{size:"small",onClick:Dt,disabled:!Mt.value,theme:X.peers.Button,themeOverrides:X.peerOverrides.Button},{default:()=>c.value.undo}),A.includes("redo")&&a(Q,{size:"small",onClick:zt,disabled:!Nt.value,theme:X.peers.Button,themeOverrides:X.peerOverrides.Button},{default:()=>c.value.redo})):null)}return{mergedClsPrefix:b,namespace:k,selfRef:r,hsla:je,rgba:ue,mergedShow:m,mergedDisabled:u,isMounted:Jt(),adjustedTo:rt(e),mergedValue:w,handleTriggerClick(){R(!0)},handleClickOutside(n){var _;!((_=r.value)===null||_===void 0)&&_.contains(Qt(n))||R(!1)},renderPanel:Tt,cssVars:B?void 0:Ge,themeClass:te==null?void 0:te.themeClass,onRender:te==null?void 0:te.onRender}},render(){const{mergedClsPrefix:e,onRender:o}=this;return o==null||o(),a("div",{class:[this.themeClass,`${e}-color-picker`],ref:"selfRef",style:this.cssVars},a(ho,null,{default:()=>[a(fo,null,{default:()=>a(Go,{clsPrefix:e,value:this.mergedValue,hsla:this.hsla,disabled:this.mergedDisabled,onClick:this.handleTriggerClick})}),a(vo,{placement:this.placement,show:this.mergedShow,containerClass:this.namespace,teleportDisabled:this.adjustedTo===rt.tdkey,to:this.adjustedTo},{default:()=>a(Lt,{name:"fade-in-scale-up-transition",appear:this.isMounted},{default:()=>this.mergedShow?Kt(this.renderPanel(),[[Gt,this.handleClickOutside,void 0,{capture:!0}]]):null})})]}))}});function ii(){return io}const ri=Yt({name:"DynamicInput",common:oo,peers:{Input:to,Button:eo},self:ii}),st=kt("n-dynamic-input"),li=K({name:"DynamicInputInputPreset",props:{clsPrefix:{type:String,required:!0},value:{type:String,default:""},disabled:Boolean,parentPath:String,path:String,onUpdateValue:{type:Function,required:!0}},setup(){const{mergedThemeRef:e,placeholderRef:o}=Ae(st);return{mergedTheme:e,placeholder:o}},render(){const{mergedTheme:e,placeholder:o,value:r,clsPrefix:i,onUpdateValue:l,disabled:t}=this;return a("div",{class:`${i}-dynamic-input-preset-input`},a(z,{theme:e.peers.Input,"theme-overrides":e.peerOverrides.Input,value:r,placeholder:o,onUpdateValue:l,disabled:t}))}}),ai=K({name:"DynamicInputPairPreset",props:{clsPrefix:{type:String,required:!0},value:{type:Object,default:()=>({key:"",value:""})},disabled:Boolean,parentPath:String,path:String,onUpdateValue:{type:Function,required:!0}},setup(e){const{mergedThemeRef:o,keyPlaceholderRef:r,valuePlaceholderRef:i}=Ae(st);return{mergedTheme:o,keyPlaceholder:r,valuePlaceholder:i,handleKeyInput(l){e.onUpdateValue({key:l,value:e.value.value})},handleValueInput(l){e.onUpdateValue({key:e.value.key,value:l})}}},render(){const{mergedTheme:e,keyPlaceholder:o,valuePlaceholder:r,value:i,clsPrefix:l,disabled:t}=this;return a("div",{class:`${l}-dynamic-input-preset-pair`},a(z,{theme:e.peers.Input,"theme-overrides":e.peerOverrides.Input,value:i.key,class:`${l}-dynamic-input-pair-input`,placeholder:o,onUpdateValue:this.handleKeyInput,disabled:t}),a(z,{theme:e.peers.Input,"theme-overrides":e.peerOverrides.Input,value:i.value,class:`${l}-dynamic-input-pair-input`,placeholder:r,onUpdateValue:this.handleValueInput,disabled:t}))}}),ni=g("dynamic-input",{width:"100%"},[g("dynamic-input-item",`
 margin-bottom: 10px;
 display: flex;
 flex-wrap: nowrap;
 `,[g("dynamic-input-preset-input",{flex:1,alignItems:"center"}),g("dynamic-input-preset-pair",`
 flex: 1;
 display: flex;
 align-items: center;
 `,[g("dynamic-input-pair-input",[U("&:first-child",{"margin-right":"12px"})])]),D("action",`
 align-self: flex-start;
 display: flex;
 justify-content: flex-end;
 flex-shrink: 0;
 flex-grow: 0;
 margin: var(--action-margin);
 `,[ee("icon",{cursor:"pointer"})]),U("&:last-child",{marginBottom:0})]),g("form-item",`
 padding-top: 0 !important;
 margin-right: 0 !important;
 `,[g("form-item-blank",{paddingTop:"0 !important"})])]),Oe=new WeakMap,si=Object.assign(Object.assign({},Ee.props),{max:Number,min:{type:Number,default:0},value:Array,defaultValue:{type:Array,default:()=>[]},preset:{type:String,default:"input"},keyField:String,itemClass:String,itemStyle:[String,Object],keyPlaceholder:{type:String,default:""},valuePlaceholder:{type:String,default:""},placeholder:{type:String,default:""},disabled:Boolean,showSortButton:Boolean,createButtonProps:Object,onCreate:Function,onRemove:Function,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],onClear:Function,onInput:[Function,Array]}),vt=K({name:"DynamicInput",props:si,setup(e,{slots:o}){const{mergedComponentPropsRef:r,mergedClsPrefixRef:i,mergedRtlRef:l,inlineThemeDisabled:t}=qe(),u=Ae(lo,null),c=N(e.defaultValue),b=pe(e,"value"),k=lt(b,c),B=Ee("DynamicInput","-dynamic-input",ni,ri,e,i),$=j(()=>{const{value:d}=k;if(Array.isArray(d)){const{max:f}=e;return f!==void 0&&d.length>=f}return!1}),h=j(()=>{const{value:d}=k;return Array.isArray(d)?d.length<=e.min:!0}),m=j(()=>{var d,f;return(f=(d=r==null?void 0:r.value)===null||d===void 0?void 0:d.DynamicInput)===null||f===void 0?void 0:f.buttonSize});function R(d){const{onInput:f,"onUpdate:value":x,onUpdateValue:y}=e;f&&he(f,d),x&&he(x,d),y&&he(y,d),c.value=d}function Z(d,f){if(d==null||typeof d!="object")return f;const x=Ze(d)?We(d):d;let y=Oe.get(x);return y===void 0&&Oe.set(x,y=ro()),y}function s(d,f){const{value:x}=k,y=Array.from(x!=null?x:[]),H=y[d];if(y[d]=f,H&&f&&typeof H=="object"&&typeof f=="object"){const J=Ze(H)?We(H):H,G=Ze(f)?We(f):f,re=Oe.get(J);re!==void 0&&Oe.set(G,re)}R(y)}function w(){O(-1)}function O(d){const{value:f}=k,{onCreate:x}=e,y=Array.from(f!=null?f:[]);if(x)y.splice(d+1,0,x(d+1)),R(y);else if(o.default)y.splice(d+1,0,null),R(y);else switch(e.preset){case"input":y.splice(d+1,0,""),R(y);break;case"pair":y.splice(d+1,0,{key:"",value:""}),R(y);break}}function E(d){const{value:f}=k;if(!Array.isArray(f))return;const{min:x}=e;if(f.length<=x)return;const{onRemove:y}=e;y&&y(d);const H=Array.from(f);H.splice(d,1),R(H)}function C(d,f,x){if(f<0||x<0||f>=d.length||x>=d.length||f===x)return;const y=d[f];d[f]=d[x],d[x]=y}function se(d,f){const{value:x}=k;if(!Array.isArray(x))return;const y=Array.from(x);d==="up"&&C(y,f,f-1),d==="down"&&C(y,f,f+1),R(y)}at(st,{mergedThemeRef:B,keyPlaceholderRef:pe(e,"keyPlaceholder"),valuePlaceholderRef:pe(e,"valuePlaceholder"),placeholderRef:pe(e,"placeholder")});const W=yt("DynamicInput",l,i),De=j(()=>{const{self:{actionMargin:d,actionMarginRtl:f}}=B.value;return{"--action-margin":d,"--action-margin-rtl":f}}),F=t?xt("dynamic-input",void 0,De,e):void 0;return{locale:$t("DynamicInput").localeRef,rtlEnabled:W,buttonSize:m,mergedClsPrefix:i,NFormItem:u,uncontrolledValue:c,mergedValue:k,insertionDisabled:$,removeDisabled:h,handleCreateClick:w,ensureKey:Z,handleValueChange:s,remove:E,move:se,createItem:O,mergedTheme:B,cssVars:t?void 0:De,themeClass:F==null?void 0:F.themeClass,onRender:F==null?void 0:F.onRender}},render(){const{$slots:e,itemClass:o,buttonSize:r,mergedClsPrefix:i,mergedValue:l,locale:t,mergedTheme:u,keyField:c,itemStyle:b,preset:k,showSortButton:B,NFormItem:$,ensureKey:h,handleValueChange:m,remove:R,createItem:Z,move:s,onRender:w,disabled:O}=this;return w==null||w(),a("div",{class:[`${i}-dynamic-input`,this.rtlEnabled&&`${i}-dynamic-input--rtl`,this.themeClass],style:this.cssVars},!Array.isArray(l)||l.length===0?a(Q,Object.assign({block:!0,ghost:!0,dashed:!0,size:r},this.createButtonProps,{disabled:this.insertionDisabled||O,theme:u.peers.Button,themeOverrides:u.peerOverrides.Button,onClick:this.handleCreateClick}),{default:()=>ct(e["create-button-default"],()=>[t.create]),icon:()=>ct(e["create-button-icon"],()=>[a(Se,{clsPrefix:i},{default:()=>a(ht,null)})])}):l.map((E,C)=>a("div",{key:c?E[c]:h(E,C),"data-key":c?E[c]:h(E,C),class:[`${i}-dynamic-input-item`,o],style:b},mt(e.default,{value:l[C],index:C},()=>[k==="input"?a(li,{disabled:O,clsPrefix:i,value:l[C],parentPath:$?$.path.value:void 0,path:$!=null&&$.path.value?`${$.path.value}[${C}]`:void 0,onUpdateValue:se=>{m(C,se)}}):k==="pair"?a(ai,{disabled:O,clsPrefix:i,value:l[C],parentPath:$?$.path.value:void 0,path:$!=null&&$.path.value?`${$.path.value}[${C}]`:void 0,onUpdateValue:se=>{m(C,se)}}):null]),mt(e.action,{value:l[C],index:C,create:Z,remove:R,move:s},()=>[a("div",{class:`${i}-dynamic-input-item__action`},a(Po,{size:r},{default:()=>[a(Q,{disabled:this.removeDisabled||O,theme:u.peers.Button,themeOverrides:u.peerOverrides.Button,circle:!0,onClick:()=>{R(C)}},{icon:()=>a(Se,{clsPrefix:i},{default:()=>a(wo,null)})}),a(Q,{disabled:this.insertionDisabled||O,circle:!0,theme:u.peers.Button,themeOverrides:u.peerOverrides.Button,onClick:()=>{Z(C)}},{icon:()=>a(Se,{clsPrefix:i},{default:()=>a(ht,null)})}),B?a(Q,{disabled:C===0||O,circle:!0,theme:u.peers.Button,themeOverrides:u.peerOverrides.Button,onClick:()=>{s("up",C)}},{icon:()=>a(Se,{clsPrefix:i},{default:()=>a(So,null)})}):null,B?a(Q,{disabled:C===l.length-1||O,circle:!0,theme:u.peers.Button,themeOverrides:u.peerOverrides.Button,onClick:()=>{s("down",C)}},{icon:()=>a(Se,{clsPrefix:i},{default:()=>a(_o,null)})}):null]}))]))))}}),gt=["mdi-air-humidifier-off","mdi-chili-off","mdi-cigar-off","mdi-clock-time-eight","mdi-clock-time-eight-outline","mdi-clock-time-eleven","mdi-clock-time-eleven-outline","mdi-clock-time-five","mdi-clock-time-five-outline","mdi-clock-time-four","mdi-clock-time-four-outline","mdi-clock-time-nine","mdi-clock-time-nine-outline","mdi-clock-time-one","mdi-clock-time-one-outline","mdi-clock-time-seven","mdi-clock-time-seven-outline","mdi-clock-time-six","mdi-clock-time-six-outline","mdi-clock-time-ten","mdi-clock-time-ten-outline","mdi-clock-time-three","mdi-clock-time-three-outline","mdi-clock-time-twelve","mdi-clock-time-twelve-outline","mdi-clock-time-two","mdi-clock-time-two-outline","mdi-cog-refresh","mdi-cog-refresh-outline","mdi-cog-sync","mdi-cog-sync-outline","mdi-content-save-cog","mdi-content-save-cog-outline","mdi-cosine-wave","mdi-cube-off","mdi-cube-off-outline","mdi-dome-light","mdi-download-box","mdi-download-box-outline","mdi-download-circle","mdi-download-circle-outline","mdi-fan-alert","mdi-fan-chevron-down","mdi-fan-chevron-up","mdi-fan-minus","mdi-fan-plus","mdi-fan-remove","mdi-fan-speed-1","mdi-fan-speed-2","mdi-fan-speed-3","mdi-food-drumstick","mdi-food-drumstick-off","mdi-food-drumstick-off-outline","mdi-food-drumstick-outline","mdi-food-steak","mdi-food-steak-off","mdi-fuse-alert","mdi-fuse-off","mdi-heart-minus","mdi-heart-minus-outline","mdi-heart-off-outline","mdi-heart-plus","mdi-heart-plus-outline","mdi-heart-remove","mdi-heart-remove-outline","mdi-hours-24","mdi-incognito-circle","mdi-incognito-circle-off","mdi-lingerie","mdi-microwave-off","mdi-minus-circle-off","mdi-minus-circle-off-outline","mdi-motion-sensor-off","mdi-pail-minus","mdi-pail-minus-outline","mdi-pail-off","mdi-pail-off-outline","mdi-pail-outline","mdi-pail-plus","mdi-pail-plus-outline","mdi-pail-remove","mdi-pail-remove-outline","mdi-pine-tree-fire","mdi-power-plug-off-outline","mdi-power-plug-outline","mdi-printer-eye","mdi-printer-search","mdi-puzzle-check","mdi-puzzle-check-outline","mdi-rug","mdi-sawtooth-wave","mdi-set-square","mdi-smoking-pipe-off","mdi-spoon-sugar","mdi-square-wave","mdi-table-split-cell","mdi-ticket-percent-outline","mdi-triangle-wave","mdi-waveform","mdi-wizard-hat","mdi-ab-testing","mdi-abjad-arabic","mdi-abjad-hebrew","mdi-abugida-devanagari","mdi-abugida-thai","mdi-access-point","mdi-access-point-network","mdi-access-point-network-off","mdi-account","mdi-account-alert","mdi-account-alert-outline","mdi-account-arrow-left","mdi-account-arrow-left-outline","mdi-account-arrow-right","mdi-account-arrow-right-outline","mdi-account-box","mdi-account-box-multiple","mdi-account-box-multiple-outline","mdi-account-box-outline","mdi-account-cancel","mdi-account-cancel-outline","mdi-account-cash","mdi-account-cash-outline","mdi-account-check","mdi-account-check-outline","mdi-account-child","mdi-account-child-circle","mdi-account-child-outline","mdi-account-circle","mdi-account-circle-outline","mdi-account-clock","mdi-account-clock-outline","mdi-account-cog","mdi-account-cog-outline","mdi-account-convert","mdi-account-convert-outline","mdi-account-cowboy-hat","mdi-account-details","mdi-account-details-outline","mdi-account-edit","mdi-account-edit-outline","mdi-account-group","mdi-account-group-outline","mdi-account-hard-hat","mdi-account-heart","mdi-account-heart-outline","mdi-account-key","mdi-account-key-outline","mdi-account-lock","mdi-account-lock-outline","mdi-account-minus","mdi-account-minus-outline","mdi-account-multiple","mdi-account-multiple-check","mdi-account-multiple-check-outline","mdi-account-multiple-minus","mdi-account-multiple-minus-outline","mdi-account-multiple-outline","mdi-account-multiple-plus","mdi-account-multiple-plus-outline","mdi-account-multiple-remove","mdi-account-multiple-remove-outline","mdi-account-music","mdi-account-music-outline","mdi-account-network","mdi-account-network-outline","mdi-account-off","mdi-account-off-outline","mdi-account-outline","mdi-account-plus","mdi-account-plus-outline","mdi-account-question","mdi-account-question-outline","mdi-account-remove","mdi-account-remove-outline","mdi-account-search","mdi-account-search-outline","mdi-account-settings","mdi-account-settings-outline","mdi-account-star","mdi-account-star-outline","mdi-account-supervisor","mdi-account-supervisor-circle","mdi-account-supervisor-outline","mdi-account-switch","mdi-account-switch-outline","mdi-account-tie","mdi-account-tie-outline","mdi-account-tie-voice","mdi-account-tie-voice-off","mdi-account-tie-voice-off-outline","mdi-account-tie-voice-outline","mdi-account-voice","mdi-adjust","mdi-adobe","mdi-adobe-acrobat","mdi-air-conditioner","mdi-air-filter","mdi-air-horn","mdi-air-humidifier","mdi-air-purifier","mdi-airbag","mdi-airballoon","mdi-airballoon-outline","mdi-airplane","mdi-airplane-landing","mdi-airplane-off","mdi-airplane-takeoff","mdi-airport","mdi-alarm","mdi-alarm-bell","mdi-alarm-check","mdi-alarm-light","mdi-alarm-light-outline","mdi-alarm-multiple","mdi-alarm-note","mdi-alarm-note-off","mdi-alarm-off","mdi-alarm-plus","mdi-alarm-snooze","mdi-album","mdi-alert","mdi-alert-box","mdi-alert-box-outline","mdi-alert-circle","mdi-alert-circle-check","mdi-alert-circle-check-outline","mdi-alert-circle-outline"],ui={class:"w-full"},di={key:0,class:"h-150 w-300 overflow-y-scroll"},ci=["onClick"],mi={key:1},pi={__name:"IconPicker",props:{value:String},emits:["update:value"],setup(e,{emit:o}){const r=e,i=o,l=N(r.value),t=N(gt);function u(){t.value=gt.filter(b=>b.includes(l.value))}function c(b){l.value=b,i("update:value",l.value)}return ao(l,()=>{u(),i("update:value",l.value)},{debounce:200}),(b,k)=>(Y(),$e("div",ui,[v(p(go),{trigger:"click",placement:"bottom-start"},{trigger:S(()=>[v(p(z),{value:l.value,"onUpdate:value":[k[0]||(k[0]=B=>l.value=B),u],placeholder:"请输入图标名称"},{prefix:S(()=>k[1]||(k[1]=[Pe("span",{class:"i-mdi:magnify text-18"},null,-1)])),suffix:S(()=>[v(Xe,{icon:l.value,size:18},null,8,["icon"])]),_:1},8,["value"])]),footer:S(()=>k[2]||(k[2]=[Ve(" 更多图标去 "),Pe("a",{class:"text-blue",target:"_blank",href:"https://icones.js.org/collection/all"}," Icones ",-1),Ve(" 查看 ")])),default:S(()=>[t.value.length?(Y(),$e("ul",di,[(Y(!0),$e(no,null,so(t.value,(B,$)=>(Y(),$e("li",{key:$,class:"mx-5 inline-block cursor-pointer hover:text-cyan",onClick:h=>c(B)},[v(Xe,{icon:B,size:18},null,8,["icon"])],8,ci))),128))])):(Y(),$e("div",mi,[v(Xe,{icon:l.value,size:18},null,8,["icon"])]))]),_:1})]))}},hi={class:"m-30 flex items-center"},fi={style:{display:"flex","align-items":"center",width:"100%"}},vi={style:{display:"flex","flex-direction":"column",width:"100%",gap:"10px"}},gi={__name:"index",setup(e){const{t:o}=uo(),r=co(),i=N(!1),l=N(null),t=N({site_url:"",site_keywords:"",site_name:"",site_desc:"",primary_color:"",site_splitter:"",site_icon:"",site_apple_icon:"",bottom_icon:"",bottom_desc:"",icp:"",entries:[{name:"",icon:"",url:""}],hero_autoplay:!0,hero_interval:5e3,hero_show_indicators:!0,hero_show_controls:!0,hero_images:[{url:"",title:"",description:""}]});function u(){var h,m,R,Z,s,w;console.log("初始化meta表单数据，metaSetting:",r.metaSetting),t.value={site_url:r.metaSetting.site_url||"",site_keywords:r.metaSetting.site_keywords||"",site_name:r.metaSetting.site_name||"",site_desc:r.metaSetting.site_desc||"",primary_color:r.metaSetting.primary_color||"",site_splitter:r.metaSetting.site_splitter||"",site_icon:r.metaSetting.site_icon||"",site_apple_icon:r.metaSetting.site_apple_icon||"",bottom_icon:r.metaSetting.bottom_icon||"",bottom_desc:r.metaSetting.bottom_desc||"",icp:r.metaSetting.icp||"",entries:(h=r.metaSetting.entries)!=null?h:[{name:"",icon:"",url:""}],hero_autoplay:(m=r.metaSetting.hero_autoplay)!=null?m:!0,hero_interval:(R=r.metaSetting.hero_interval)!=null?R:5e3,hero_show_indicators:(Z=r.metaSetting.hero_show_indicators)!=null?Z:!0,hero_show_controls:(s=r.metaSetting.hero_show_controls)!=null?s:!0,hero_images:(w=r.metaSetting.hero_images)!=null?w:[{url:"",title:"",description:""}]},console.log("初始化后的meta表单数据:",t.value)}function c(){return Be(this,null,function*(){var h;i.value=!0,(h=l.value)==null||h.validate(m=>Be(this,null,function*(){if(m)return;const R={meta:t.value};yield po.updateMetaSetting(R).then(()=>{r.setMetaSetting(t.value),i.value=!1,$message.success(o("common.text.save_success"))}).catch(()=>{i.value=!1})}))})}const b={};function k(){return{name:"",icon:"",url:""}}function B(){return{url:"",title:"",description:""}}const $="#20809F";return mo(()=>Be(this,null,function*(){console.log("meta页面挂载，开始获取网站设置数据");const h=yield r.getMetaSetting();console.log("获取网站设置结果:",h),console.log("store中的metaSetting:",r.metaSetting),yield St(),u()})),(h,m)=>{const R=oi,Z=pi;return Y(),Ue(bo,{title:h.$t("views.setting.label_meta_setting")},{default:S(()=>[Pe("div",hi,[v(p(xo),{ref_key:"infoFormRef",ref:l,"label-placement":"top","label-align":"left","label-width":"100",model:t.value,rules:b,class:"w-500"},{default:S(()=>[v(p(q),{label:h.$t("views.setting.label_site_url"),path:"site_url"},{default:S(()=>[v(p(z),{value:t.value.site_url,"onUpdate:value":m[0]||(m[0]=s=>t.value.site_url=s),type:"text",placeholder:h.$t("views.setting.placeholder_site_url"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),v(p(q),{label:h.$t("views.setting.label_site_name"),path:"site_name"},{default:S(()=>[v(p(z),{value:t.value.site_name,"onUpdate:value":m[1]||(m[1]=s=>t.value.site_name=s),type:"text",placeholder:h.$t("views.setting.placeholder_site_name"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),v(p(q),{label:h.$t("views.setting.label_site_splitter"),path:"site_splitter"},{default:S(()=>[v(p(z),{value:t.value.site_splitter,"onUpdate:value":m[2]||(m[2]=s=>t.value.site_splitter=s),type:"text",placeholder:h.$t("views.setting.placeholder_site_splitter"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),v(p(q),{label:h.$t("views.setting.label_site_desc"),path:"site_desc"},{default:S(()=>[v(p(z),{value:t.value.site_desc,"onUpdate:value":m[3]||(m[3]=s=>t.value.site_desc=s),type:"text",placeholder:h.$t("views.setting.placeholder_site_desc"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),v(p(q),{label:h.$t("views.setting.label_site_keywords"),path:"site_keywords"},{default:S(()=>[v(p(z),{value:t.value.site_keywords,"onUpdate:value":m[4]||(m[4]=s=>t.value.site_keywords=s),type:"text",placeholder:h.$t("views.setting.placeholder_site_keywords"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),v(p(q),{label:h.$t("views.setting.label_site_icon"),path:"site_icon"},{default:S(()=>[v(p(z),{value:t.value.site_icon,"onUpdate:value":m[5]||(m[5]=s=>t.value.site_icon=s),type:"text",placeholder:h.$t("views.setting.placeholder_site_icon"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),t.value.site_icon!=null&&t.value.site_icon!=""?(Y(),Ue(p(Me),{key:0,width:"50",src:t.value.site_icon,class:"icon"},null,8,["src"])):Fe("",!0),v(p(q),{label:h.$t("views.setting.label_site_apple_icon"),path:"site_apple_icon"},{default:S(()=>[v(p(z),{value:t.value.site_apple_icon,"onUpdate:value":m[6]||(m[6]=s=>t.value.site_apple_icon=s),type:"text",placeholder:h.$t("views.setting.placeholder_site_apple_icon"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),t.value.site_apple_icon!=null&&t.value.site_apple_icon!=""?(Y(),Ue(p(Me),{key:1,width:"50",src:t.value.site_apple_icon,class:"icon"},null,8,["src"])):Fe("",!0),v(p(q),{label:h.$t("views.setting.label_bottom_icon"),path:"bottom_icon"},{default:S(()=>[v(p(z),{value:t.value.bottom_icon,"onUpdate:value":m[7]||(m[7]=s=>t.value.bottom_icon=s),type:"text",placeholder:h.$t("views.setting.placeholder_bottom_icon"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),t.value.bottom_icon!=null&&t.value.bottom_icon!=""?(Y(),Ue(p(Me),{key:2,width:"50",src:t.value.bottom_icon,class:"icon"},null,8,["src"])):Fe("",!0),v(p(q),{label:h.$t("views.setting.label_bottom_desc"),path:"bottom_desc"},{default:S(()=>[v(p(z),{value:t.value.bottom_desc,"onUpdate:value":m[8]||(m[8]=s=>t.value.bottom_desc=s),type:"text",placeholder:h.$t("views.setting.placeholder_bottom_desc"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),v(p(q),{label:h.$t("views.setting.label_primary_color"),path:"primary_color"},{default:S(()=>[v(R,{value:t.value.primary_color,"onUpdate:value":m[9]||(m[9]=s=>t.value.primary_color=s),"show-alpha":!1,"default-value":p($),class:"w-200"},null,8,["value","default-value"])]),_:1},8,["label"]),v(p(q),{label:h.$t("views.setting.label_icp"),path:"icp"},{default:S(()=>[v(p(z),{value:t.value.icp,"onUpdate:value":m[10]||(m[10]=s=>t.value.icp=s),type:"text",placeholder:h.$t("views.setting.placeholder_icp"),clearable:""},null,8,["value","placeholder"])]),_:1},8,["label"]),v(p(q),{label:h.$t("views.setting.label_entries"),path:"entries",class:"w-800"},{default:S(()=>[v(p(vt),{value:t.value.entries,"onUpdate:value":m[11]||(m[11]=s=>t.value.entries=s),"on-create":k},{"create-button-default":S(()=>[Ve(pt(p(o)("views.setting.label_create_entries")),1)]),default:S(({value:s})=>[Pe("div",fi,[v(p(z),{value:s.name,"onUpdate:value":w=>s.name=w,placeholder:h.$t("views.setting.placeholder_entry_name"),type:"text",style:{"margin-left":"5px"}},null,8,["value","onUpdate:value","placeholder"]),v(Z,{value:s.icon,"onUpdate:value":w=>s.icon=w,style:{"margin-left":"5px"}},null,8,["value","onUpdate:value"]),v(p(z),{value:s.url,"onUpdate:value":w=>s.url=w,placeholder:h.$t("views.setting.placeholder_entry_url"),type:"text",style:{"margin-left":"5px"}},null,8,["value","onUpdate:value","placeholder"])])]),_:1},8,["value"])]),_:1},8,["label"]),v(p(q),{label:"封面自动播放",path:"hero_autoplay"},{default:S(()=>[v(p(Je),{value:t.value.hero_autoplay,"onUpdate:value":m[12]||(m[12]=s=>t.value.hero_autoplay=s)},null,8,["value"])]),_:1}),v(p(q),{label:"播放间隔(毫秒)",path:"hero_interval"},{default:S(()=>[v(p(ko),{value:t.value.hero_interval,"onUpdate:value":m[13]||(m[13]=s=>t.value.hero_interval=s),min:1e3,max:1e4,step:1e3},null,8,["value"])]),_:1}),v(p(q),{label:"显示指示器",path:"hero_show_indicators"},{default:S(()=>[v(p(Je),{value:t.value.hero_show_indicators,"onUpdate:value":m[14]||(m[14]=s=>t.value.hero_show_indicators=s)},null,8,["value"])]),_:1}),v(p(q),{label:"显示控制按钮",path:"hero_show_controls"},{default:S(()=>[v(p(Je),{value:t.value.hero_show_controls,"onUpdate:value":m[15]||(m[15]=s=>t.value.hero_show_controls=s)},null,8,["value"])]),_:1}),v(p(q),{label:"封面图片",path:"hero_images",class:"w-800"},{default:S(()=>[v(p(vt),{value:t.value.hero_images,"onUpdate:value":m[16]||(m[16]=s=>t.value.hero_images=s),"on-create":B},{"create-button-default":S(()=>m[17]||(m[17]=[Ve(" 添加封面图片 ")])),default:S(({value:s})=>[Pe("div",vi,[v(p(z),{value:s.url,"onUpdate:value":w=>s.url=w,placeholder:"图片地址",type:"text"},null,8,["value","onUpdate:value"]),v(p(z),{value:s.title,"onUpdate:value":w=>s.title=w,placeholder:"图片标题",type:"text"},null,8,["value","onUpdate:value"]),v(p(z),{value:s.description,"onUpdate:value":w=>s.description=w,placeholder:"图片描述",type:"text"},null,8,["value","onUpdate:value"]),s.url?(Y(),Ue(p(Me),{key:0,src:s.url,width:"200",class:"icon"},null,8,["src"])):Fe("",!0)])]),_:1},8,["value"])]),_:1}),v(p(Q),{type:"primary",loading:i.value,onClick:c},{default:S(()=>[Ve(pt(h.$t("common.buttons.save")),1)]),_:1},8,["loading"])]),_:1},8,["model"])])]),_:1},8,["title"])}}},Mi=yo(gi,[["__scopeId","data-v-ee6d71fe"]]);export{Mi as default};
